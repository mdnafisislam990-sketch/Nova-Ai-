package com.novaai.assistant.ui

import android.Manifest
import android.content.Intent
import android.os.Build
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.novaai.assistant.ai.LlmClient
import com.novaai.assistant.assist.Session
import com.novaai.assistant.control.NovaAccessibilityService
import com.novaai.assistant.data.Repo
import com.novaai.assistant.data.Store
import com.novaai.assistant.utils.Perms
import com.novaai.assistant.utils.toast

private class SItem(
    val icon: String, val title: String, val sub: String = "", val badge: String? = null,
    val toggle: Boolean? = null, val onToggle: (Boolean) -> Unit = {}, val onClick: () -> Unit = {}
)

@Composable
fun SettingsScreen(onNav: (String) -> Unit, onKeys: () -> Unit, onHey: (Boolean) -> Unit, onNotif: (Boolean) -> Unit, onControl: () -> Unit) {
    val ctx = LocalContext.current
    val live by Session.active.collectAsState()
    var needWake by remember { mutableStateOf(Store.bool("need_wake")) }
    var muteNotif by remember { mutableStateOf(Store.bool("mute_notif")) }
    val notif by Store.notif.collectAsState()
    var query by remember { mutableStateOf("") }
    var name by remember { mutableStateOf(Store.name) }
    var editName by remember { mutableStateOf(false) }
    var lang by remember { mutableStateOf(Store.str("lang", "bn-BD")) }

    val ready = listOf(
        LlmClient.provider() != null,
        Perms.has(ctx, Manifest.permission.RECORD_AUDIO),
        Perms.overlay(ctx),
        Build.VERSION.SDK_INT < 33 || Perms.has(ctx, Manifest.permission.POST_NOTIFICATIONS)
    ).count { it }
    val connected = if (LlmClient.provider() != null) "Connected" else "Add key"

    val essentials = listOf(
        SItem("🔑", "Connections", "AI keys: Gemini, OpenAI, Groq, Image AI", connected, onClick = onKeys),
        SItem("🎧", "Live AI", "Orb and Mini Orb voice: device speech + your AI key", connected, onClick = onKeys),
        SItem("🎙️", "Always-on mic", "Mic stays on and runs your voice commands until you turn it off", toggle = live, onToggle = onHey),
        SItem("👋", "Say \"Nova\" first", "Only react when you start with Nova / Hey Nova (use this in noisy places)", toggle = needWake,
            onToggle = { needWake = it; Store.putBool("need_wake", it) }),
        SItem("🔕", "Silence mic beep (stronger)", "Also mutes the notification sound while the mic is on. On some phones this can mute the ringtone too.", toggle = muteNotif,
            onToggle = { muteNotif = it; Store.putBool("mute_notif", it); ctx.toast("Applies next time the mic starts") }),
        SItem("🔔", "Nova notification", "A permanent notification. Tap it to open the mini orb anywhere. Uses no battery.", toggle = notif, onToggle = onNotif),
        SItem("💬", "Help & Feedback", "Report a problem or share an idea", onClick = { onNav("help") }),
        SItem("🌐", "Follow Nova", "Facebook · Instagram and TikTok", onClick = { onNav("follow") })
    )
    val more = listOf(
        SItem("🤖", "AI & voice", "Voice, language, personality, chats", onClick = onKeys),
        SItem("🧠", "Assistant", "Try: next video · auto scroll 8 · call Rahim · message Rahim saying hi · open TikTok · back · mic off",
            onClick = { ctx.toast("Try: \"next video\" or \"call Rahim\"") }),
        SItem("⌨️", "Voice keyboard", "Type or speak in any app",
            onClick = { ctx.toast("Voice keyboard is coming in a later version") }),
        SItem("🛡️", "Phone control & safety", "Calls, SMS, contacts + Accessibility for tap, scroll, TikTok, WhatsApp",
            badge = if (NovaAccessibilityService.isOn()) "On" else "Setup", onClick = onControl),
        SItem("🎨", "Appearance & language", "Voice language: " + if (lang == "bn-BD") "Bangla" else "English (tap to switch)",
            onClick = { lang = if (lang == "bn-BD") "en-US" else "bn-BD"; Store.put("lang", lang); ctx.toast("Voice language changed") }),
        SItem("💾", "Data & backup", "Share a backup of your chats and tasks", onClick = {
            val send = Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, Repo.exportJson())
            ctx.startActivity(Intent.createChooser(send, "Nova backup").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        }),
        SItem("⬆️", "Updates", "v5.5", onClick = { ctx.toast("Nova v5.5") }),
        SItem("🔒", "Privacy & about", "", onClick = { ctx.toast("Data stays on your phone. Only your messages go to your AI provider.") }),
        SItem("🚪", "Log out", "", onClick = { Store.clearAll(); Repo.load(); name = Store.name; ctx.toast("Data cleared") })
    )

    fun match(i: SItem) = query.isBlank() || (i.title + i.sub).contains(query, ignoreCase = true)

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text("Settings", fontSize = 22.sp, fontWeight = FontWeight.Bold)
        OutlinedTextField(query, { query = it }, Modifier.fillMaxWidth(), placeholder = { Text("Search settings") }, singleLine = true)
        NovaCard(Modifier.fillMaxWidth(), onClick = { editName = true }) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(38.dp).clip(CircleShape).background(NovaColors.Cyan), contentAlignment = Alignment.Center) {
                    Text(name.take(1).uppercase(), color = Color.Black, fontWeight = FontWeight.Bold)
                }
                Spacer(Modifier.width(12.dp))
                Column { Text(name); Text("Tap to change name", color = NovaColors.TextDim, fontSize = 12.sp) }
            }
        }
        NovaCard(Modifier.fillMaxWidth()) {
            Column {
                Text("Setup · $ready of 4 ready", fontWeight = FontWeight.SemiBold)
                Text(if (ready == 4) "Nova is fully set up" else "Add an AI key and allow microphone, overlay and notifications",
                    color = NovaColors.TextDim, fontSize = 12.sp)
            }
        }
        if (essentials.any(::match)) Text("ESSENTIALS", color = NovaColors.TextDim, fontSize = 11.sp)
        essentials.filter(::match).forEach { Row2(it) }
        if (more.any(::match)) Text("MORE SETTINGS", color = NovaColors.TextDim, fontSize = 11.sp)
        more.filter(::match).forEach { Row2(it) }
        Spacer(Modifier.height(8.dp))
    }

    if (editName) PromptDialog("Your name", "Name", name, onDismiss = { editName = false }) {
        Store.name = it; name = it; editName = false
    }
}

@Composable
private fun Row2(i: SItem) {
    NovaCard(Modifier.fillMaxWidth(), onClick = if (i.toggle == null) i.onClick else null) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(i.icon, fontSize = 20.sp)
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(i.title)
                if (i.sub.isNotEmpty()) Text(i.sub, color = NovaColors.TextDim, fontSize = 12.sp)
            }
            i.badge?.let { Text(it, color = NovaColors.Green, fontSize = 11.sp) }
            if (i.toggle != null) Switch(checked = i.toggle, onCheckedChange = i.onToggle)
        }
    }
}
