package com.novaai.assistant.ai

import android.content.Context
import com.novaai.assistant.assist.IntentRouter
import com.novaai.assistant.assist.Routed
import com.novaai.assistant.control.CmdJson
import com.novaai.assistant.control.DeviceActions
import com.novaai.assistant.control.Executor
import com.novaai.assistant.data.Repo
import com.novaai.assistant.data.Store
import com.novaai.assistant.voice.Tts
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

class NoKeyException : Exception("NO_KEY")

object LlmClient {
    private const val SYSTEM =
        "You are Nova, a warm, concise voice assistant. Reply in the same language the user writes " +
            "(Bangla, English or mixed). Keep replies short and natural to be spoken aloud. No markdown. " +
            "You can also control the user's phone. When the user asks you to DO something on the phone, " +
            "reply with ONLY one JSON object and nothing else, for example {\"action\":\"call\",\"who\":\"Rahim\"}. " +
            "Actions: open_app(name), call(who), sms(who,text), whatsapp(who,text), next, previous, " +
            "auto_scroll(seconds), stop_scroll, back, home, recents, notifications, tap(text), type(text), like, " +
            "volume(dir=up|down|mute), media(kind=play|pause|next|prev), torch(on=true|false), wifi, bluetooth, time. " +
            "For normal conversation answer in plain text, never JSON."

    fun provider(): String? = when {
        Store.str("k_gemini").isNotBlank() -> "gemini"
        Store.str("k_groq").isNotBlank() -> "groq"
        Store.str("k_openai").isNotBlank() -> "openai"
        else -> null
    }

    private fun model(p: String): String = Store.str("m_$p").ifBlank {
        when (p) {
            "gemini" -> "gemini-flash-latest"
            "groq" -> "llama-3.3-70b-versatile"
            else -> "gpt-4o-mini"
        }
    }

    /** history: (fromUser, text) pairs, newest last. */
    suspend fun chat(history: List<Pair<Boolean, String>>): String = withContext(Dispatchers.IO) {
        val p = provider() ?: throw NoKeyException()
        val key = Store.str("k_$p").trim()
        val mem = Store.str("memory")
        val sys = SYSTEM + if (mem.isBlank()) "" else "\nWhat you know about the user: $mem"
        val msgs = history.dropWhile { !it.first }

        if (p == "gemini") {
            val contents = JSONArray()
            msgs.forEach { (u, t) ->
                contents.put(
                    JSONObject().put("role", if (u) "user" else "model")
                        .put("parts", JSONArray().put(JSONObject().put("text", t)))
                )
            }
            val body = JSONObject()
                .put("systemInstruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", sys))))
                .put("contents", contents).toString()
            val res = post(
                "https://generativelanguage.googleapis.com/v1beta/models/${model(p)}:generateContent",
                mapOf("x-goog-api-key" to key), body
            )
            val parts = JSONObject(res).getJSONArray("candidates").getJSONObject(0)
                .getJSONObject("content").getJSONArray("parts")
            buildString { for (i in 0 until parts.length()) append(parts.getJSONObject(i).optString("text")) }.trim()
        } else {
            val arr = JSONArray().put(JSONObject().put("role", "system").put("content", sys))
            msgs.forEach { (u, t) -> arr.put(JSONObject().put("role", if (u) "user" else "assistant").put("content", t)) }
            val url = if (p == "groq") "https://api.groq.com/openai/v1/chat/completions"
            else "https://api.openai.com/v1/chat/completions"
            val body = JSONObject().put("model", model(p)).put("messages", arr).toString()
            val res = post(url, mapOf("Authorization" to "Bearer $key"), body)
            JSONObject(res).getJSONArray("choices").getJSONObject(0).getJSONObject("message").getString("content").trim()
        }
    }

    private fun post(url: String, headers: Map<String, String>, body: String): String {
        val c = URL(url).openConnection() as HttpURLConnection
        try {
            c.requestMethod = "POST"
            c.connectTimeout = 15000
            c.readTimeout = 60000
            c.doOutput = true
            c.setRequestProperty("Content-Type", "application/json")
            headers.forEach { (k, v) -> c.setRequestProperty(k, v) }
            c.outputStream.use { it.write(body.toByteArray()) }
            val code = c.responseCode
            val text = (if (code in 200..299) c.inputStream else c.errorStream)?.bufferedReader()?.use { it.readText() } ?: ""
            if (code !in 200..299) {
                val msg = runCatching { JSONObject(text).getJSONObject("error").getString("message") }.getOrDefault("HTTP $code")
                throw IOException(msg)
            }
            return text
        } finally {
            c.disconnect()
        }
    }

    fun imageUrl(prompt: String) =
        "https://image.pollinations.ai/prompt/" + URLEncoder.encode(prompt, "UTF-8") + "?width=768&height=768&nologo=true"
}

data class Reply(val text: String, val close: Boolean = false, val spoken: Boolean = false)

/** One path for typed chat, in-app voice, the floating orb and the always-on mic. */
object ChatEngine {
    /**
     * speak = true means voice mode: quiet commands (scroll, back, like...) are not logged or spoken,
     * and the answer is read aloud; onSpoken runs when the speech ends.
     */
    suspend fun send(ctx: Context, text: String, speak: Boolean = false, onSpoken: (() -> Unit)? = null): Reply {
        val app = ctx.applicationContext
        val r = try {
            IntentRouter.route(app, text)
        } catch (e: Exception) {
            Routed(true, "That didn't work: ${e.message ?: "unknown error"}")
        }
        if (r.handled && r.quiet && speak) return Reply(r.reply, r.close)

        Repo.addUser(text)
        Repo.busy.value = true
        var ok = true
        val out: String = try {
            when {
                r.searchQuery != null -> {
                    DeviceActions.webSearch(app, r.searchQuery)
                    try {
                        LlmClient.chat(listOf(true to "Answer briefly in 2 short sentences, in my language: ${r.searchQuery}"))
                    } catch (e: Exception) {
                        "Opening Google results for ${r.searchQuery}"
                    }
                }
                r.handled -> r.reply
                else -> {
                    val hist = Repo.messages.value.filter { it.imageUrl == null }.takeLast(12).map { it.fromUser to it.text }
                    val answer = LlmClient.chat(hist)
                    val cmd = CmdJson.tryParse(answer)
                    if (cmd != null) Executor.run(app, cmd).reply else answer
                }
            }
        } catch (e: NoKeyException) {
            ok = false
            "Add an AI key first: Settings → Connections. Free Gemini key: aistudio.google.com/apikey"
        } catch (e: Exception) {
            ok = false
            "Couldn't get an answer: ${e.message ?: "unknown error"}"
        }
        Repo.addAssistant(out)
        Repo.busy.value = false
        val spoken = speak && ok
        if (spoken) Tts.speak(app, out, onSpoken)
        return Reply(out, r.close, spoken)
    }

    fun image(prompt: String) {
        Repo.addUser("🖼️ $prompt")
        Repo.addAssistant("", LlmClient.imageUrl(prompt))
    }
}
