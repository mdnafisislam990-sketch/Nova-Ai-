package com.novaai.assistant.widget

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.core.app.NotificationCompat
import com.novaai.assistant.R
import com.novaai.assistant.utils.Perms

object NovaNotification {
    private const val CH = "nova_silent"
    private const val ID = 1001

    fun createChannel(ctx: Context) {
        val nm = ctx.getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CH, "Nova notification", NotificationManager.IMPORTANCE_MIN).apply {
                setShowBadge(false); setSound(null, null); enableVibration(false)
            }
        )
    }

    fun post(ctx: Context) {
        if (Build.VERSION.SDK_INT >= 33 && !Perms.has(ctx, Manifest.permission.POST_NOTIFICATIONS)) return
        // Tapping starts the orb service directly (no trampoline), which Android 12+ allows.
        val tap = PendingIntent.getForegroundService(
            ctx, 0,
            Intent(ctx, OrbOverlayService::class.java).setAction(OrbOverlayService.ACTION_SHOW),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val n = NotificationCompat.Builder(ctx, CH)
            .setSmallIcon(R.drawable.ic_stat_nova)
            .setContentTitle("Nova")
            .setContentText("Tap to talk to Nova")
            .setOngoing(true).setSilent(true).setOnlyAlertOnce(true)
            .setPriority(NotificationCompat.PRIORITY_MIN)
            .setCategory(NotificationCompat.CATEGORY_SERVICE)
            .setContentIntent(tap)
            .build()
        ctx.getSystemService(NotificationManager::class.java).notify(ID, n)
    }

    fun cancel(ctx: Context) = ctx.getSystemService(NotificationManager::class.java).cancel(ID)
}
